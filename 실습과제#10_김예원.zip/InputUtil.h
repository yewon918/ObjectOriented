#pragma once
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

class  InputUtil { //������ �Է¹޴� �Լ�
public:
	static void InputValue(int &);
	static void InputValue(string &);
	static void InputValue(char *);
	static void InputValue(float &);
	static void InputValue(double &);

};
