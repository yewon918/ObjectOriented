#pragma once
#include <iostream>
#include <iomanip>
#include <string>
#include "Subject.h"

using namespace std;

class Student { //�л� Ŭ����
protected:
	string m_name;
	int m_hakbun;
	int m_subnum;
	Subject* m_sub; //��������
	float m_aveGPA;

public:
	void InputData();
	void PrintData();
	void CalcAveGPA();
	void Modify();
	Subject* SubSearch(string subname);

	string GetName() const; //m_name
	int GetHakbun() const; //m_hakbun
	int GetSubNum() const; //m_subnum ����
	float GetAveGPA() const; //m_aveGPA

	//������ �Ҹ���
	Student();
	Student(string name, int hakbun, int subnum, Subject *sub);
	Student(const Student& std);
	~Student();

	friend void ShowData(const Student &);

};