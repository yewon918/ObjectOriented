#pragma once
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

class Subject { //���� Ŭ����
protected:
	string m_name;
	int m_hakjum;
	string m_grade;
	float m_GPA;

public:
	void InputData();

	static void PrintTitle();
	void PrintData();
	void CalcGPA();
	void Modify();

	//������ �Լ�
	string GetName() const;
	int GetHakjum() const;
	string GetGrade() const;
	float GetGPA() const;

	//������ �Ҹ���
	Subject();
	Subject(string name, int hakjum, string grade);
	Subject(const Subject& sub);
	~Subject();

};

