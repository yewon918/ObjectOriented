#pragma once
#include <iostream>
#include <iomanip>
#include <string>
#include "Subject.h"

using namespace std;

class Student { //�л� Ŭ����

	friend void ShowData(const Student &);

protected:
	string m_name;
	int m_hakbun;
	int m_subnum;
	Subject* m_sub;
	float m_aveGPA;

public:
	void Initialize();
	void Initialize(string, int, int, Subject*);
	void Remove();
	void InputValue(int &);
	void InputValue(string &);
	void InputData();
	void PrintData();
	void CalcAveGPA();

	string GetName(); //m_name
	int GetHakbun(); //m_hakbun
	int GetSubNum(); //m_subnum ����
	float GetAveGPA(); //m_aveGPA


}; 
