#pragma once
#include <iostream>
#include <iomanip>
#include <cstring>
#include <string>

using namespace std;
class Subject { //���� Ŭ����
protected:
	string m_name;
	int m_hakjum;
	string m_grade;
	float m_GPA;

public:
	void InputValue(int &);
	void InputValue(string &);
	void InputData();

	void PrintTitle();
	void PrintData();
	void CalcGPA();
	void Modify();

	//������ �Լ�
	string GetName();
	int GetHakjum();
	string GetGrade();
	float GetGPA();

	//������ �Ҹ���
	Subject();
	Subject(string name, int hakjum, string grade);
	Subject(const Subject& sub);
	~Subject();

};

